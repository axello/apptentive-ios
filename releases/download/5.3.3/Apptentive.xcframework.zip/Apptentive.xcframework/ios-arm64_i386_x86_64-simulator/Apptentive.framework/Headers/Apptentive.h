//
//  Apptentive.h
//  Apptentive
//
//  Created by Frank Schmitt on 9/15/20.
//  Copyright © 2020 Apptentive, Inc. All rights reserved.
//

#ifndef Apptentive_h
#define Apptentive_h

#import <Apptentive/ApptentiveMain.h>
#import <Apptentive/ApptentiveStyleSheet.h>

#endif /* Apptentive_h */
